#!/bin/sh

PATH=/home/yaoweibin/nginx/sbin:$PATH prove -r -v t
