MyWebSQL-Theme-dark
===================

A dark coloured theme for MyWebSQL