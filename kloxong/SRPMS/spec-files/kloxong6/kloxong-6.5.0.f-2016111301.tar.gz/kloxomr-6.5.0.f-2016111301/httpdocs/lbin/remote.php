<?php 
chdir("..");
include_once "htmllib/lib/include.php";
include_once "htmllib/lib/remotelib.php";

remote_main();

