#ifndef README_H
#define README_H

#include "stralloc.h"
#include "strerr.h"

extern struct strerr readme_err;

extern int readme (stralloc *);

#endif
