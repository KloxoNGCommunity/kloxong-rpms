This is a simple and hackish tool to monitor the 'show status' command in Tomahawk.
