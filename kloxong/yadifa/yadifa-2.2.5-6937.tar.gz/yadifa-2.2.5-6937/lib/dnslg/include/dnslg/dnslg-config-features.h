#pragma once
// version 2.2.5.0-6937
#define DNSLG_VERSION 0x020205001b19LL// include/dnslg/dnslg-config-features.h

