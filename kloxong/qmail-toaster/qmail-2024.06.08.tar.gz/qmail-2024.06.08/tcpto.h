#ifndef TCPTO_H
#define TCPTO_H

extern int tcpto();
extern void tcpto_err();
extern void tcpto_clean();

#endif
