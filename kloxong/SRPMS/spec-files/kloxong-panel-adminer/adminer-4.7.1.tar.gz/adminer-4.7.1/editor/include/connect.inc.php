<?php
$connection->select_db($adminer->database());
