<?php 

class jailed__linux extends lxDriverClass
{
	function dbactionUpdate($subaction) {
	}

}
