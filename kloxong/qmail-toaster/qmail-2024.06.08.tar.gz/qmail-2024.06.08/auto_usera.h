#ifndef AUTO_USERA_H
#define AUTO_USERA_H

extern char auto_usera[];

#endif
