/*
 * $Log: socket_v6loopback.c,v $
 * Revision 1.1  2005-06-15 22:13:07+05:30  Cprogrammer
 * Initial revision
 *
 */
#ifdef IPV6
const unsigned char V6any[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
#endif
