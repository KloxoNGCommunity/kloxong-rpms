	<link href="/htmllib/css/common.css" rel="stylesheet" type="text/css" />
	<link href="/htmllib/lib/admin_login.css" rel="stylesheet" type="text/css" />

	<script language="javascript" src="/htmllib/js/login.js"></script>
	<script language="javascript" src="/htmllib/js/preop.js"></script>
	<script language="javascript" src="/htmllib/js/lxa.js"></script>
