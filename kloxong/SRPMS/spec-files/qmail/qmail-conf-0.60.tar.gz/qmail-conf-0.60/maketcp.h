#ifndef MAKETCP_H
#define MAKETCP_H

extern void maketcp (int);

#endif
