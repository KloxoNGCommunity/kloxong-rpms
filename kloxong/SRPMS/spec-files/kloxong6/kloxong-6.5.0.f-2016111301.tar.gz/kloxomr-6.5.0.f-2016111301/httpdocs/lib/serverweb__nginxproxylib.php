<?php

include_once("serverweb__lib.php");

class serverweb__nginxproxy extends serverweb__
{
	function __construct()
	{
		parent::__construct();
	}
}