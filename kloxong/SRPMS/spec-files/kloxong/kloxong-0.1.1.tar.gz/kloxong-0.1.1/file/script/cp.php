<?php
$hostname = $_SERVER['SERVER_NAME'];
$domainame = substr($hostname, 3);
?>

<html>
<meta http-equiv=refresh content='0; url=https://www.<?php echo $domainame ?>:7777'>
</html>


