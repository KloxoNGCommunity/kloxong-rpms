<?php 

class Tree extends Lxclass {



static $__desc_tree_l = array("", "",  "");

function get(){}
function write(){}


static function initThisList($parent, $class)
{
	$v = null;
	return $v;
}

}
