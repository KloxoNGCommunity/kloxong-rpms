<?php 
include_once "lib/html/displayinclude.php";

webcommandline_main();
