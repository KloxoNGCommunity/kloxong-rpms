#pragma once
// version 2.2.5.0-6937
#define DNSZONE_VERSION 0x020205001b19LL// include/dnszone/dnszone-config-features.h

