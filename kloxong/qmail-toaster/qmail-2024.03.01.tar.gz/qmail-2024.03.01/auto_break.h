#ifndef AUTO_BREAK_H
#define AUTO_BREAK_H

extern char auto_break[];

#endif
