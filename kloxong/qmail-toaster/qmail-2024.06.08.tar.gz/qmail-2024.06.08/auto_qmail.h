#ifndef AUTO_QMAIL_H
#define AUTO_QMAIL_H

extern char auto_qmail[];

#endif
