/*
 * $Log: tryulong64.c,v $
 * Revision 1.1  2004-05-14 00:45:23+05:30  Cprogrammer
 * Initial revision
 *
 */
void
main()
{
	unsigned long   u;
	u = 1;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	u += u;
	if (!u)
		_exit(1);
	_exit(0);
}
