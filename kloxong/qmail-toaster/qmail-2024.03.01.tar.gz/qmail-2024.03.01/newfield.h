#ifndef NEWFIELD_H
#define NEWFIELD_H

#include "stralloc.h"

extern stralloc newfield_date;
extern int newfield_datemake();

extern stralloc newfield_msgid;
extern int newfield_msgidmake();

#endif
