
<tr> <td>
<table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111"         |class=normaltxt bgcolor=#eeeeee>
  <form method="POST" action="/__lx_path__/formmail.php">
  <tr>
  <br>
    Just fill in the form and you will be contacted within a working day.<br> <br>
    <td align="right">Name:</td>
    <td><input type="text" name="realname" size="25"></td></tr>

  <tr>
    <td align="right">Organization:</td>
    <td><input type="text" name="organization" size="25"></td></tr>

  <tr>
    <td align="right">e-mail:</td>
    <td><input type="text" name="email" size="25">

  <tr>
    <td align="right" valign="top">Comments:</td>
    <td ><textarea rows="5" name="message" cols="50"></textarea></td></tr>

  <tr>
    <td align="right" colspan=2>
        <input type="hidden" name="subject" value="__lx_domain__ # Contact Us">
        <button type="submit">Send</button></td></tr>

  </form>
  </table>
  </td> </tr>
</table>
</div>

