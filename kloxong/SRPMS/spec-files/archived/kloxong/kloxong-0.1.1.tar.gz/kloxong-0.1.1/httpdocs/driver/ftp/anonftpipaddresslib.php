<?php 

class anonftpmisc_b extends LxaClass {
}
class anonftpipaddress extends Lxdb {
 
static $__desc = array("", "",  "Anonyous Ftp");


}
