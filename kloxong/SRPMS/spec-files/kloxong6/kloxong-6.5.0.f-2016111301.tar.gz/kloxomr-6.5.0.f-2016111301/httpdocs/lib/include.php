<?php 

throw new Exception('lib/include.php_shoundnt_be_included');

