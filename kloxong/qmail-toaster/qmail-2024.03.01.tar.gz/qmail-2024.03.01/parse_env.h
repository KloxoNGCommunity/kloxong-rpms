/*
 * $Id: parse_env.h,v 1.1 2023-01-13 12:15:01+05:30 Cprogrammer Exp mbhangui $
 */
#ifndef _PARSE_ENV_H
#define _PARSE_ENV_H

int             parse_env(char *);

#endif
/*
 * Log: $
 */
