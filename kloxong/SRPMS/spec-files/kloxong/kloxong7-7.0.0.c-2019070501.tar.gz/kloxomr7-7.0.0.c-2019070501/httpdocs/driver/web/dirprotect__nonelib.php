<?php 

include_once("dirprotect__lib.php");

class dirprotect__none extends dirprotect__
{

}
