#ifndef GETLN_H
#define GETLN_H

extern int getln();
extern int getln2();

#endif
