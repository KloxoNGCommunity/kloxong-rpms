<?php 

include_once "htmllib/coredisplaylib.php";
