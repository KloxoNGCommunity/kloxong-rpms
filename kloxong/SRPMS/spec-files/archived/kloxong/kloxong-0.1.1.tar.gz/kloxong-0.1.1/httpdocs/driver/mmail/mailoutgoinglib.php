<?php

class Mailoutgoing extends Lxdb
{
}
