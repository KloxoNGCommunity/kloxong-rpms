<?php 

class clientskel extends lxdb {

static $__desc =   array("", "",  "skeleton"); 
static $__desc_skeletonarchive =   array("F", "",  "archive_of_skeleton"); 
static $__acdesc_update_update =   array("t", "",  "upload_skeleton_archive"); 

function updateform($subaction, $param)
{

}

}
