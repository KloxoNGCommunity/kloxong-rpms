<?php 

include_once "htmllib/phplib/lib/gbllib.php";

class Gbl extends Gbllib {

}
