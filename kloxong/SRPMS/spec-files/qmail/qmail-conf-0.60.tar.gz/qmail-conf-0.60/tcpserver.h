#ifndef TCPSERVER_H
#define TCPSERVER_H

extern void tcpserver_env (char *, char *, char *);
extern void tcpserver_run (char *, char *);

#endif
