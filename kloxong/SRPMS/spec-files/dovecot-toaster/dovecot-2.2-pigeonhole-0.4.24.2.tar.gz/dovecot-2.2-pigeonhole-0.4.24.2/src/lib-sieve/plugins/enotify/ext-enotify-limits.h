/* Copyright (c) 2002-2018 Pigeonhole authors, see the included COPYING file
 */

#ifndef __EXT_ENOTIFY_LIMITS_H
#define __EXT_ENOTIFY_LIMITS_H

#define EXT_ENOTIFY_MAX_SCHEME_LEN  32

#endif /* __EXT_ENOTIFY_LIMITS_H */
