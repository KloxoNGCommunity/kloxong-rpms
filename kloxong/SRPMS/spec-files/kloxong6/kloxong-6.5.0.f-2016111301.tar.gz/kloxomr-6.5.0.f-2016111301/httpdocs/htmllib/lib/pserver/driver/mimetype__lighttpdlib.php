<?php 
class mimetype__apache extends Lxdriverclass {

function dbactionUpdate($subaction)
{
	createMimeType();
}

function dbactionAdd()
{
	createMimeType();
}
function dbactionDelete()
{
	createMimeType();
}

function createMimeType()
{

}

}
