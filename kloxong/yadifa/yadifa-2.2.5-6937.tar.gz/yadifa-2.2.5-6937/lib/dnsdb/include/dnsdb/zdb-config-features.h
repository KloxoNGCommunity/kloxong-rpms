#pragma once
#define ZDB_HAS_RRCACHE_ENABLED 0
#define ZDB_HAS_DNSSEC_SUPPORT 1
#define ZDB_HAS_NSEC_SUPPORT 1
#define ZDB_HAS_NSEC3_SUPPORT 1
#define ZDB_HAS_ACL_SUPPORT 1
#define ZDB_HAS_TSIG_SUPPORT 1
#define ZDB_HAS_NSID_SUPPORT 1
// version 2.2.5.0-6937
#define DNSDB_VERSION 0x020205001b19LL// include/dnsdb/zdb-config-features.h

