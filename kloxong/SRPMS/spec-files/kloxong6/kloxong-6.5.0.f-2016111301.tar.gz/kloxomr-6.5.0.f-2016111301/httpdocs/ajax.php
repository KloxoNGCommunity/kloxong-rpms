<?php 

include_once "htmllib/coredisplaylib.php";

log_log("ajax", var_export($_REQUEST, true));


include_once "htmllib/lib/ajaxcore.php";

//log_log("ajax", var_export($_COOKIE, true));


