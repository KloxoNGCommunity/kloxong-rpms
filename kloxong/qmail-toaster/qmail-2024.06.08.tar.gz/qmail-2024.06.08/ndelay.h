#ifndef NDELAY_H
#define NDELAY_H

extern int ndelay_on();
extern int ndelay_off();

#endif
