/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 if you have the <arpa/nameser.h> header file. */

/* Define to 1 if you have the <dlfcn.h> header file. */

/* HAVE_EVP_SHA256 */
#define HAVE_EVP_SHA256 1

