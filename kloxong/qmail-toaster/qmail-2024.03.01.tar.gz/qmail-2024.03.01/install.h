void d(char *home, char*subdir, int uid, int gid, int mode);
void h(char *home, int uid, int gid, int mode);
void c(char *home, char *subdir, char *file, int uid, int gid, int mode);
void z(char *home, char *file, int len, int uid, int gid, int mode);
void p(char *home, char *fifo, int uid, int gid, int mode);
