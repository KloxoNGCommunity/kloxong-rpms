#include <sys/types.h>
#include <sys/wait.h>

void main()
{
  waitpid(0,0,0);
}
