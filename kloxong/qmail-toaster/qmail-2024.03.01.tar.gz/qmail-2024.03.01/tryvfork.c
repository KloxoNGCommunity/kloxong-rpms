void main()
{
  vfork();
}
