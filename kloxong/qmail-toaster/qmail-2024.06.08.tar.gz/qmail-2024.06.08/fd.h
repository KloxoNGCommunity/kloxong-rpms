#ifndef FD_H
#define FD_H

extern int fd_copy();
extern int fd_move();

#endif
