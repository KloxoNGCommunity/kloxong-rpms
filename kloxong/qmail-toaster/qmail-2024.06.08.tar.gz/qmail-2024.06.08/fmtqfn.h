#ifndef FMTQFN_H
#define FMTQFN_H

extern unsigned int fmtqfn();

#define FMTQFN 40 /* maximum space needed, if len(dirslash) <= 10 */

#endif
