<?php 

class Spam__none extends lxDriverClass
{
	static function installMe()
	{
	}

	static function uninstallMe()
	{
	}
}
