#ifndef MAKELOGDIR_H
#define MAKELOGDIR_H

extern void makelogdir (char *, int, int);

#endif
