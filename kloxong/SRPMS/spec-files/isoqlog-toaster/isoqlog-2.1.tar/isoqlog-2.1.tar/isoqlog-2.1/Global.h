
#ifndef GLOBAL_H
#define GLOBAL_H
#include <time.h>

enum {
        BUFSIZE = 1024,
        KEYSIZE = 64,
        VALSIZE = 256
};

time_t secs;
time_t today ;
struct tm *t;
struct tm *t2;




#endif


