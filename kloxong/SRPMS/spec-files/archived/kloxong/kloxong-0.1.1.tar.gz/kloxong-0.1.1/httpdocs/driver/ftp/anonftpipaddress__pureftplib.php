<?php 

class anonftpipaddress__pureftp extends Lxdriverclass {

}
