#ifndef __POLICY_H_
   #define __POLICY_H_

int policy_check(void);

#endif
