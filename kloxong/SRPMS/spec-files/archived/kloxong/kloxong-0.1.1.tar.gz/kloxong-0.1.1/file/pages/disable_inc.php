	<br><br>
	<div align="center">
		<table width="600" class="content_header">
			<tr>
				<td><br />
				<font size="3" face="arial" color="#336699"><strong>This is  
				KloxoNG Disable Page</strong></font> </td>
			</tr>
		</table>
		<br />
		<table width="600" class="content_body">
			<tr>
				<td width="100%" bgcolor="#F5F5F5">
				<p>If you are seeing this page, it means that web has been DISABLED. </p>
				<p>Please contact the 
				adminstrator...<br /></p>
				</td>
			</tr>
		</table>
	</div>