#ifndef SRS_H
#define SRS_H

extern stralloc srs_result;
extern stralloc srs_error;
extern int srsforward(char *);
extern int srsreverse(char *);

#endif
